const express=require("express")
const app=express()
const path=require("path")
const { getImages } =require("./seed/getImage")
const ejsMate=require('ejs-mate')
const method=require("method-override")
const catchAsync=require("./utils/wrapAsync")
const appError=require("./utils/expressError")
const model=require("./models/model")
const mongoose=require("mongoose")
const joi=require("joi")
const { error } = require("console")
mongoose.connect('mongodb://127.0.0.1:27017/camp',{
    useNewUrlParser: true,

    useUnifiedTopology: true
})

const db=mongoose.connection;
db.on("error",console.error.bind(console,"connection error"))
db.once("open",()=>{
    console.log("Database connected")
})


async function assignImage(){
    const imagesArray = await getImages();
    const randomIndex = Math.floor(Math.random() * imagesArray.length);
    const randomImage = imagesArray[randomIndex];
    return randomImage

}
const Camps=model

// camp.save().then((data)=>console.log(data)).catch((err)=>console.log(err))

app.set("views",path.join(__dirname,"views"))
app.set("view engine","ejs")
app.use(method('_method'))//use every single request
app.use(express.urlencoded({extended:true}))
app.engine("ejs",ejsMate)

app.get("/",(req,res)=>{
    res.render("./home")
})

app.get("/camps",async (req,res)=>{
    const camps=await Camps.find({})
    
    res.render("./camps/index",{camps})
    

    
})
app.get("/camps/new",async (req,res)=>{

    
    res.render("./camps/new")
  
})

//middleware
const validate=function(req,res,next){
    const campSchema=joi.object({
        title:joi.string().required(),
        price:joi.number().min(0),
        location:joi.string().required(),
        description:joi.string().required()
    }).required()

    const {error}=campSchema.validate(req.body)
    
    if(error){
        const msg=error.details[0].message
        
        throw new appError(msg,400)
    }
    else{next()}

}
app.post("/camps",validate,catchAsync(async(req,res)=>{
    
    
        const camp=new Camps({...req.body,image:await assignImage()})
        await camp.save()
        res.redirect(`/camps/${camp._id}`)}

))
app.put("/camps/:id",validate,catchAsync(async (req,res,next)=>{
    const {id}=req.params
    const camp=await Camps.findByIdAndUpdate(id,{...req.body})
    res.redirect(`/camps/${id}`)
    
    
}))

app.delete("/camps/:id",async (req,res)=>{
    const {id}=req.params
    const camp=await Camps.findByIdAndDelete(id)
    res.redirect("/camps")
})
app.get("/camps/:id",catchAsync(async (req,res)=>{
    const {id}=req.params
    const camp=await Camps.findById(id)
    res.render("./camps/show",{camp})
   
}))
app.get("/camps/:id/edit",async (req,res)=>{
    const {id}=req.params
    const camp=await Camps.findById(id)
    res.render("./camps/edit",{camp})
       
})

app.get("/error",(req,res)=>{
    throw new Error("Errooooooooooor")
})

app.all("*",(req,res,next)=>{
    next(new appError("Page not found",404))
})


app.use((err,req,res,next)=>{
    const {statusCode=500}=err
    if(!err.message){err.message="Error"}
    res.status(statusCode).render("./error",{err})
})

app.listen(3000,(req,res)=>{
    console.log("Listening")
})

