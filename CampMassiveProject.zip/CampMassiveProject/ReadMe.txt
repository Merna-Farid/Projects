cd seed
node index.js

cd..
node app.js

Browser url write:localhost:3000/camps