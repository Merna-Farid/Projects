const mongoose=require("mongoose")
const Schema=mongoose.Schema


const CampSchema=new Schema({
    title:String,
    price: { type: Number, required: true },
    location:String,
   description:String,
   image:String

})

module.exports=mongoose.model("camp",CampSchema)